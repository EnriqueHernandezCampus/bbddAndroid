package com.example.a041121;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);
        Button botonLogin = findViewById(R.id.b_b_login);
        EditText email = findViewById(R.id.et_login_email);
        EditText password = findViewById(R.id.et_login_password);
        botonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkUser(email.getText().toString(), password.getText().toString()) != null) {
                Intent i = new Intent(LoginActivity.this,Bienvenida.class);
                startActivity(i);

                }else{
                    Toast.makeText(LoginActivity.this, R.string.msj_ko, Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public User checkUser(String email, String pwd) {
        DBManager dbManager = new DBManager(this);
        dbManager.open();
        dbManager.findUserById(email, pwd);
        return dbManager.findUserById(email, pwd);
    }
}