package com.example.a041121;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Button botonRegister = findViewById(R.id.b_b_register);
        EditText nombre= findViewById(R.id.et_name);
        EditText email= findViewById(R.id.et_email);
        EditText password= findViewById(R.id.et_register_password);

        botonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor mCursor;
                DBManager dbManager = new DBManager(RegisterActivity.this).open();
                dbManager.insert(nombre.getText().toString(), email.getText().toString(), password.getText().toString());
                Cursor cursor = dbManager.fetch();


                while (cursor.moveToNext()) {

                    String data3 = cursor.getString((cursor.getColumnIndex(DatabaseHelper.NOMBRE)));
                    String data4 = cursor.getString((cursor.getColumnIndex(DatabaseHelper.PASSWORD)));
                    String data5 = cursor.getString((cursor.getColumnIndex(DatabaseHelper.EMAIL)));
                    Log.e("Resultado: NOMBRE: ",  data3 +" password: "+ data4 +" Email: "+ data5);
                }
                Intent i = new Intent(RegisterActivity.this, Bienvenida.class);
                startActivity(i);

/*                if (cursor != null) {
                    cursor.moveToFirst();
                    String data = cursor.getString((cursor.getColumnIndex(DatabaseHelper.SUBJECT)));
                    String data2 = cursor.getString((cursor.getColumnIndex(DatabaseHelper.DESC)));
                    Log.e("Resultado", data+data2);
                }*/

                Toast.makeText(RegisterActivity.this, R.string.msj_ok, Toast.LENGTH_LONG).show();
            }
        });
    }
}