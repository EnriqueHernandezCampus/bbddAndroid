package com.example.a041121;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class ListaUsuarios extends AppCompatActivity {
    ListView lista;
    List<String> listaStr;
    ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_usuarios);
        lista = findViewById(R.id.lv_listaUsuarios);
        listaStr = new ArrayList<>();
        Cursor c = listUser();
        c.moveToFirst();
        for (int i = 0; i < c.getCount(); i++)  {
            listaStr.add("Usuario: "+c.getString(1) + " - email: " + c.getString(3));
            c.moveToNext();
        }
            adapter = new ArrayAdapter<>(this, R.layout.support_simple_spinner_dropdown_item, listaStr);
            lista.setAdapter(adapter);


    }

    public Cursor listUser() {
        DBManager dbManager = new DBManager(this);
        dbManager.open();
        dbManager.fetch();
        return dbManager.fetch();
    }

}