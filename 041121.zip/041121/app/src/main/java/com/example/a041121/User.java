package com.example.a041121;

public class User {


    private int id;
    private String nombre;
    private String email;
    private String password;

    // Constructor de un objeto Contactos
    public User(int id, String nombre, String email, String password) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.password = password;

    }

    // Recuperar/establecer ID
    public int getID() {
        return id;
    }

    public void setID(int id) {
        this.id = id;
    }

    // Recuperar/establecer NOMBRE
    public String getNOMBRE() {
        return nombre;
    }

    public void setNOMBRE(String nombre) {
        this.nombre = nombre;
    }
    // Recuperar/establecer NOMBRE
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


    // Recuperar/establecer EMAIL
    public String getPassword() {
        return password;
    }

    public void setPasswordt(String password) {
        this.password = password;
    }
}

